Pay-Pilot Backend 9.4.2

Plaid Hosted Link mobile redirect fix.

Railway variable PLAID_REDIRECT_URI should be:
https://pay-pilot-backend-production.up.railway.app/plaid/oauth-redirect

Add that exact HTTPS URI in Plaid Dashboard > Developers > API > Allowed redirect URIs.
PLAID_COMPLETION_REDIRECT_URI may remain paypilot://plaid-complete.
