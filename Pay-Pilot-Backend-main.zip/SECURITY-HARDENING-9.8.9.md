# Pay-Pilot security hardening — 9.8.9

- Per-install device authentication protects Plaid account/transaction endpoints.
- Server rejects cross-device user IDs.
- Plaid access tokens are AES-256-GCM encrypted at rest when TOKEN_ENCRYPTION_KEY is configured.
- Production refuses to start without TOKEN_ENCRYPTION_KEY.
- CORS is restricted, request bodies are capped, and API rate limiting is enabled.
- Security headers and no-store caching are enabled.
- Sensitive Plaid payloads/tokens are no longer written to application logs.
- Dependencies are pinned instead of using `latest`.

## Railway action required
Before deploying this backend with `PLAID_ENV=production`, add `TOKEN_ENCRYPTION_KEY` as a long random secret in Railway Variables. Never commit its value to GitHub or place it in the Android app.

Changing TOKEN_ENCRYPTION_KEY after tokens have been encrypted will make those tokens unreadable. If rotation is required later, implement a controlled re-encryption migration first.
